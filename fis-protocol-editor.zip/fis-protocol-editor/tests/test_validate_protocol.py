"""Portable CLI acceptance checks; synthetic inputs and standard library only."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


PACKAGE = Path(__file__).resolve().parents[1]
SCRIPT = PACKAGE / "scripts/validate_protocol.py"
ARTIFACTS = "АРТЕФАКТЫ И ДОКУМЕНТАЦИЯ"
DEV = "ВНЕДРЕНИЕ ИИ В РАЗРАБОТКУ В ПРОИЗВОДСТВЕ"
VALID = f"{ARTIFACTS}\n✅ 05.10.2026: Подготовлен шаблон\n🟡 Проверить шаблон @demo_ba @demo_dev\n"


class PortableValidationTests(unittest.TestCase):
    def run_check(self, text=VALID, *, date_mode="generated", extra=(), registry=None,
                  raw_registry=None, script=SCRIPT):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            protocol = root / "protocol.md"
            protocol.write_text(text, encoding="utf-8")
            participants = root / "participants.json"
            participants.write_text(raw_registry if raw_registry is not None else json.dumps(registry if registry is not None else [
                {"name": "Елена Учебная", "account": "@demo_ba"},
                {"name": "Игорь Учебный", "account": "@demo_dev"},
            ], ensure_ascii=False), encoding="utf-8")
            command = [sys.executable, str(script), str(protocol), "--mode", "portable",
                       "--participants", str(participants), "--date-mode", date_mode]
            if date_mode == "generated":
                command += ["--meeting-date", "05.10.2026"]
            return subprocess.run(command + list(extra), cwd=root, text=True, capture_output=True)

    def assert_invalid(self, text, diagnostic, **kwargs):
        result = self.run_check(text, **kwargs)
        self.assertEqual(result.returncode, 1, result.stderr + result.stdout)
        self.assertIn(diagnostic, result.stdout)
        return result

    def test_valid_and_exact_counts(self):
        result = self.run_check()
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assertIn("Items: 2 (1 done, 1 todo)", result.stdout)
        self.assertIn("Errors: 0; Warnings: 0", result.stdout)
        self.assertIn("portable", result.stdout)

    def test_duplicate_json_keys_are_rejected_without_values(self):
        for raw in (
            '[{"name":"PRIVATE_FIRST","name":"PRIVATE_LAST","account":"@demo_dev"}]',
            '[{"name":"PRIVATE_FIRST","account":"@demo_dev","account":"@demo_dev"}]',
            '[{"name":"PRIVATE_FIRST","account":"@demo_dev","metadata":{"x":1,"x":1}}]',
        ):
            with self.subTest(raw=raw):
                result = self.run_check(f'{ARTIFACTS}\n🟡 Проверить @demo_dev\n', raw_registry=raw)
                self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
                self.assertIn('duplicate JSON key', result.stdout + result.stderr)
                self.assertNotIn('PRIVATE_FIRST', result.stdout + result.stderr)
                self.assertNotIn('PRIVATE_LAST', result.stdout + result.stderr)

    def test_task_requires_space_before_account_block(self):
        self.assert_invalid(VALID.replace('шаблон @demo_ba', 'шаблон@demo_ba'), 'whitespace')

    def test_duplicate_items_warn_and_preserve_counts_across_local_headings(self):
        text = f'{ARTIFACTS}\n🟡 Проверить шаблон @demo_dev\nИгорь Учебный:\n  🟡 Проверить шаблон @demo_dev  \n'
        result = self.run_check(text)
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assertIn('duplicate item', result.stdout)
        self.assertIn('line 2', result.stdout)
        self.assertIn('line 4', result.stdout)
        self.assertIn('Items: 2 (0 done, 2 todo)', result.stdout)
        self.assertIn('Errors: 0; Warnings: 1', result.stdout)

    def test_timestamp_calendar_prefix_is_not_task_wording(self):
        for value in ('2026-10-05T10:00:00+07:00', '2026-10-05T10:00', '05.10.2026T10:00'):
            with self.subTest(value=value):
                self.assert_invalid(VALID.replace('🟡 Проверить', f'🟡 {value}: Проверить'), 'date')

    def test_calendar_prefix_with_wrong_separator_or_no_colon_is_rejected(self):
        for body in ('05.10.2026, Проверить', '05:10:2026: Проверить', '2026/10/05, Проверить'):
            with self.subTest(body=body):
                self.assert_invalid(VALID.replace('🟡 Проверить', f'🟡 {body}'), 'date')

    def test_duplicates_are_scoped_to_canonical_section(self):
        result = self.run_check(f'{ARTIFACTS}\n🟡 Проверить @demo_dev\n{DEV}\n🟡 Проверить @demo_dev\n')
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assertIn('Errors: 0; Warnings: 0', result.stdout)

    def test_standalone_copy_needs_no_original_project(self):
        with tempfile.TemporaryDirectory() as directory:
            script = Path(directory) / "validate_protocol.py"
            shutil.copyfile(SCRIPT, script)
            result = self.run_check(script=script)
            self.assertEqual(result.returncode, 0, result.stderr + result.stdout)

    def test_generated_done_date_is_meeting_date(self):
        self.assert_invalid(VALID.replace("05.10.2026", "02.10.2026"), "meeting date")

    def test_event_date_can_remain_in_wording(self):
        result = self.run_check(VALID.replace("Подготовлен шаблон", "Подготовлен шаблон (событие 02.10.2026)"))
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)

    def test_edit_preserves_accepted_date(self):
        result = self.run_check(VALID.replace("05.10.2026", "02.10.2026"), date_mode="edit")
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)

    def test_edit_partial_date_warns(self):
        result = self.run_check(VALID.replace("05.10.2026", "XX.10.2026"), date_mode="edit")
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assertIn("partial date", result.stdout)
        self.assertIn("Errors: 0; Warnings: 1", result.stdout)

    def test_generated_partial_date_rejected(self):
        self.assert_invalid(VALID.replace("05.10.2026", "XX.10.2026"), "partial date")

    def test_partial_date_known_parts_must_be_possible(self):
        for invalid in ("XX.13.2026", "32.XX.2026", "30.02.XXXX"):
            with self.subTest(invalid=invalid):
                self.assert_invalid(VALID.replace("05.10.2026", invalid), "calendar date", date_mode="edit")

    def test_required_done_date(self):
        self.assert_invalid(VALID.replace("05.10.2026: ", ""), "requires date")

    def test_real_dates_and_strict_display_format(self):
        for invalid in ("31.02.2026", "29.02.2026", "5.10.2026", "2026-10-05"):
            with self.subTest(invalid=invalid):
                self.assert_invalid(VALID.replace("05.10.2026", invalid), "date", date_mode="edit")
        result = self.run_check(VALID.replace("05.10.2026", "29.02.2024"), date_mode="edit")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_todo_date_if_present_must_be_real(self):
        for value, diagnostic in (("31.02.2026", "calendar date"), ("2026-10-05", "date"),
                                  ("5.10.2026", "date"), ("XX.10.2026", "partial date")):
            with self.subTest(value=value):
                self.assert_invalid(VALID.replace("🟡 Проверить", f"🟡 {value}: Проверить"), diagnostic)

    def test_numeric_task_title_is_not_a_date(self):
        result = self.run_check(VALID.replace("🟡 Проверить шаблон", "🟡 2FA: проверить подключение"))
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)

    def test_version_prefix_is_not_a_calendar_date(self):
        for version in ("1.2", "10.24", "1.2.3"):
            with self.subTest(version=version):
                result = self.run_check(VALID.replace("🟡 Проверить шаблон", f"🟡 {version}: проверить совместимость"))
                self.assertEqual(result.returncode, 0, result.stderr + result.stdout)

    def test_all_assignees_form_one_space_separated_trailing_block(self):
        for separator in (", ", "; ", " и "):
            with self.subTest(separator=separator):
                self.assert_invalid(VALID.replace("@demo_ba @demo_dev", f"@demo_ba{separator}@demo_dev"), "trailing block")

    def test_complete_calendar_prefix_requires_separator(self):
        self.assert_invalid(VALID.replace("🟡 Проверить", "🟡 05.10.2026 Проверить"), "date requires")

    def test_all_joint_assignees_registered(self):
        self.assert_invalid(VALID.replace("@demo_dev", "@missing_user"), "unregistered")

    def test_joint_assignment_cannot_hide_in_wording(self):
        self.assert_invalid(VALID.replace("@demo_ba @demo_dev", "@missing_user и @demo_ba"), "unregistered")

    def test_malformed_assignee_rejected(self):
        self.assert_invalid(VALID.replace("@demo_ba @demo_dev", "@я @demo_ba"), "malformed")

    def test_missing_assignee_rejected(self):
        self.assert_invalid(VALID.replace(" @demo_ba @demo_dev", ""), "must end")

    def test_sections_order_and_duplicates(self):
        self.assert_invalid(f"{DEV}\n🟡 Сделать @demo_ba\n{VALID}", "section order")
        self.assert_invalid(VALID + f"{ARTIFACTS}\n", "duplicate section")

    def test_allowed_local_heading_requires_section(self):
        result = self.run_check(VALID.replace("✅", "Елена Учебная:\nАддитивный редактор:\n✅"))
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assert_invalid("Елена Учебная:\n" + VALID, "outside section")

    def test_arbitrary_colon_text_and_unknown_sections_rejected(self):
        for line in ("Случайное замечание:", "DEVOPS", "## Артефакты", "Просто текст"):
            with self.subTest(line=line):
                self.assert_invalid(VALID + line, "unexpected line")

    def test_explicit_local_heading(self):
        result = self.run_check(VALID + "Пилот:\n", extra=["--allow-heading", "Пилот:"])
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)

    def test_only_one_optional_h1_before_sections(self):
        result = self.run_check("# Протокол встречи\n" + VALID)
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assert_invalid("# Один\n# Два\n" + VALID, "H1")
        self.assert_invalid(VALID + "# Поздний", "H1")

    def test_items_require_canonical_section(self):
        self.assert_invalid("✅ 05.10.2026: Результат\n" + VALID, "outside section")

    def test_malformed_markers_never_skipped(self):
        for line in ("🟢 Сделать @demo_ba", "- ✅ 05.10.2026: Готово", "✅🟡 Готово", "✅ 05.10.2026: ✅ Готово", "✅ 05.10.2026: ✔ Готово"):
            with self.subTest(line=line):
                self.assert_invalid(VALID + line, "marker")

    def test_no_content_and_empty_action(self):
        self.assert_invalid(f"{ARTIFACTS}\n", "no protocol items")
        self.assert_invalid(f"{ARTIFACTS}\n✅ 05.10.2026: \n", "empty")
        self.assert_invalid(f"{ARTIFACTS}\n🟡 @demo_ba\n", "empty")

    def test_invalid_registry_is_diagnosed_without_traceback(self):
        result = self.run_check(registry={"bad": "shape"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("registry", result.stderr.lower())
        self.assertNotIn("Traceback", result.stderr)

    def test_help_and_project_mode_are_distinct(self):
        result = subprocess.run([sys.executable, str(SCRIPT), "--help"], text=True, capture_output=True)
        self.assertEqual(result.returncode, 0)
        for flag in ("--mode", "portable", "project", "--date-mode", "--meeting-date", "--allow-heading"):
            self.assertIn(flag, result.stdout)

    def test_generated_requires_meeting_date(self):
        result = subprocess.run([sys.executable, str(SCRIPT), "protocol.md", "--participants", "participants.json"], text=True, capture_output=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("requires --meeting-date", result.stderr)

    def test_project_missing_dependencies_is_input_error(self):
        with tempfile.TemporaryDirectory() as directory:
            protocol = Path(directory) / "protocol.md"
            protocol.write_text(VALID, encoding="utf-8")
            result = subprocess.run([sys.executable, str(SCRIPT), str(protocol), "--mode", "project", "--repo-root", directory], cwd=directory, text=True, capture_output=True)
            self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
            self.assertIn("repo root", result.stderr)

    def test_local_heading_cannot_whitelist_invalid_marker(self):
        result = self.run_check(VALID + "🟢 Сделать @demo_ba\n", extra=["--allow-heading", "🟢 Сделать @demo_ba"])
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_project_parser_path_remains_operational(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "scripts").mkdir()
            (root / "data").mkdir()
            (root / "data/people.json").write_text("[]", encoding="utf-8")
            (root / "data/protocol-telegram-participants.json").write_text('[{"account": "@demo_ba"}]', encoding="utf-8")
            protocol = root / "protocol.md"
            protocol.write_text(f"{ARTIFACTS}\n🟡 Проверить @demo_ba\n", encoding="utf-8")
            (root / "scripts/sync_plan.py").write_text(
                'def read_people_registry(path):\n    return []\n'
                'def read_protocol_milestones(path, people):\n'
                '    return [{"protocolFile":"protocol.md", "taskStatus":"todo", '
                '"lineNumber":2, "assignees":["Учебный участник"], "title":"Проверить"}]\n', encoding="utf-8")
            result = subprocess.run([sys.executable, str(SCRIPT), str(protocol), "--mode", "project", "--repo-root", str(root)], text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
            self.assertIn("Validation mode: project", result.stdout)
            self.assertIn("Parsed items: 1 (0 done, 1 todo)", result.stdout)
            self.assertIn("Errors: 0; Warnings: 0", result.stdout)


if __name__ == "__main__":
    unittest.main()
