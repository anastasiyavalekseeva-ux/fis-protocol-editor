#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import re
import sys
from datetime import date
from pathlib import Path
from typing import Any


TELEGRAM_ACCOUNT_PATTERN = re.compile(r"@[A-Za-z0-9_]{5,32}")
TODO_LINE_PATTERN = re.compile(r"^🟡(?:\s+\d{1,2}\.\d{1,2}\.\d{4}:)?\s+(.+)$")
TODO_ASSIGNEE_SUFFIX_PATTERN = re.compile(
    r"(?P<suffix>@[A-Za-z0-9_]{5,32}(?:\s+@[A-Za-z0-9_]{5,32})*)\s*$"
)
SECTIONS = (
    "АРТЕФАКТЫ И ДОКУМЕНТАЦИЯ",
    "ВНЕДРЕНИЕ ИИ В БИЗНЕС-АНАЛИЗ В ПРОИЗВОДСТВЕ",
    "ВНЕДРЕНИЕ ИИ В РАЗРАБОТКУ В ПРОИЗВОДСТВЕ",
    "ВНЕДРЕНИЕ ИИ В ТЕСТИРОВАНИЕ В ПРОИЗВОДСТВЕ",
    "ВНЕДРЕНИЕ ИИ В ИНФРАСТРУКТУРНЫЕ ПРОЦЕССЫ",
    "РАЗРАБОТКА РЕАКТОРА ЧЕРЕЗ ИИ",
    "МАРКЕТИНГ",
    "ПРОЧЕЕ",
)
LOCAL_HEADINGS = {"Аддитивный редактор:", "Целевой UI-kit:", "Методический SWE:"}
DATE_PATTERN = re.compile(r"^(\d{2}|XX|ХХ)\.(\d{2}|XX|ХХ)\.(\d{4}|XXXX|ХХХХ)$", re.IGNORECASE)
CALENDAR_PREFIX_PATTERN = re.compile(
    r"^(?:(?:\d{1,2}|XX|ХХ)[.\-/:](?:\d{1,2}|XX|ХХ)[.\-/:](?:\d{4}|XXXX|ХХХХ)"
    r"|\d{4}[.\-/:]\d{1,2}[.\-/:]\d{1,2})(?=\D|$)", re.IGNORECASE
)
STATUS_MARKERS = ("✅", "🟡", "🟢", "❌", "🔴", "☑", "✔")


def check_date(value: str, allow_partial: bool) -> tuple[str | None, str | None]:
    """Validate known calendar parts without completing an unknown date."""
    match = DATE_PATTERN.fullmatch(value)
    if not match:
        return "date must use DD.MM.YYYY", None
    components = [int(part) if part.isdigit() else None for part in match.groups()]
    day, month, year = components
    if ((day is not None and not 1 <= day <= 31)
            or (month is not None and not 1 <= month <= 12)
            or (year is not None and not 1 <= year <= 9999)):
        return "invalid calendar date", None
    # Leap year 2000 permits every possible day when the year is unknown.
    try:
        date(year if year is not None else 2000, month if month is not None else 1,
             day if day is not None else 1)
    except ValueError:
        return "invalid calendar date", None
    if None in components:
        if allow_partial:
            return None, "partial date preserved; full calendar date not verified"
        return "partial date is not allowed in generated mode", None
    return None, None


def unique_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def read_portable_registry(path: Path) -> tuple[dict[str, str], set[str]]:
    payload = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique_json_object)
    if not isinstance(payload, list):
        raise ValueError("participant registry must contain a list")
    accounts: dict[str, str] = {}
    names: set[str] = set()
    for index, item in enumerate(payload, 1):
        if not isinstance(item, dict):
            raise ValueError(f"participant registry entry {index} must be an object")
        account = item.get("account")
        name = item.get("name")
        if not isinstance(account, str) or not TELEGRAM_ACCOUNT_PATTERN.fullmatch(account):
            raise ValueError(f"participant registry entry {index} has an invalid account")
        if not isinstance(name, str) or not name.strip():
            raise ValueError(f"participant registry entry {index} requires a name")
        name = name.strip()
        normalized = account.casefold()
        if normalized in accounts or name in names:
            raise ValueError(f"participant registry entry {index} duplicates a name or account")
        accounts[normalized] = account
        names.add(name)
    return accounts, {name + ":" for name in names} | names


def validate_portable(args: argparse.Namespace) -> int:
    accounts, names = read_portable_registry(Path(args.participants).expanduser())
    headings = LOCAL_HEADINGS | names | set(args.allow_heading)
    if any("\n" in heading or "\r" in heading or heading.startswith("#")
           or any(marker in heading for marker in STATUS_MARKERS) for heading in headings):
        raise ValueError("local heading must not contain status markers, H1, or newlines")
    errors: list[str] = []
    warnings: list[str] = []
    counts = {"done": 0, "todo": 0}
    section_index = -1
    seen_sections: set[str] = set()
    seen_items: dict[tuple[int, str], int] = {}
    title_seen = False
    for line_number, raw in enumerate(Path(args.protocol).expanduser().read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        prefix = f"line {line_number}: "
        if line in SECTIONS:
            index = SECTIONS.index(line)
            if line in seen_sections:
                errors.append(prefix + "duplicate section")
            elif index < section_index:
                errors.append(prefix + "invalid section order")
            seen_sections.add(line)
            section_index = index
            continue
        if re.fullmatch(r"#\s+\S.*", line):
            if title_seen or seen_sections:
                errors.append(prefix + "H1 must occur at most once before all sections")
            title_seen = True
            continue
        if line in headings:
            if not seen_sections:
                errors.append(prefix + "local heading outside section")
            continue
        if not line.startswith(("✅", "🟡")):
            if any(marker in line for marker in STATUS_MARKERS):
                errors.append(prefix + "invalid status marker")
            else:
                errors.append(prefix + "unexpected line: " + line)
            continue
        status = "done" if line.startswith("✅") else "todo"
        counts[status] += 1
        item_key = (section_index, line)
        if item_key in seen_items:
            warnings.append(prefix + f"duplicate item; first occurrence line {seen_items[item_key]}")
        else:
            seen_items[item_key] = line_number
        if not seen_sections:
            errors.append(prefix + "protocol item outside section")
        if len(line) < 2 or not line[1].isspace() or any(marker in line[1:] for marker in STATUS_MARKERS):
            errors.append(prefix + "invalid status marker; use exactly one followed by whitespace")
            continue
        body = line[1:].strip()
        date_text = None
        if status == "done":
            if ":" not in body:
                errors.append(prefix + "completed item requires date followed by ':'")
            else:
                date_text, body = body.split(":", 1)
                date_text, body = date_text.strip(), body.strip()
        elif CALENDAR_PREFIX_PATTERN.match(body):
            # Three components with an explicit year distinguish dates from versions.
            candidate = body.split(":", 1)
            if len(candidate) == 2:
                date_text, body = candidate[0].strip(), candidate[1].strip()
            else:
                errors.append(prefix + "date requires ':' separator")
        if date_text is not None:
            error, warning = check_date(date_text, args.date_mode == "edit")
            if error:
                errors.append(prefix + error)
            if warning:
                warnings.append(prefix + warning)
            if status == "done" and args.date_mode == "generated" and not error and date_text != args.meeting_date:
                errors.append(prefix + "completed item date must equal meeting date")
        if not body:
            errors.append(prefix + "empty item wording")
        if status == "todo":
            suffix = TODO_ASSIGNEE_SUFFIX_PATTERN.search(body)
            if not suffix:
                errors.append(prefix + "future task must end with registered Telegram usernames")
            elif not body[:suffix.start()].strip():
                errors.append(prefix + "empty task wording")
            elif not body[suffix.start() - 1].isspace():
                errors.append(prefix + "task wording and Telegram assignees require whitespace")
            elif "@" in body[:suffix.start()]:
                errors.append(prefix + "all Telegram assignees must form one trailing block separated by spaces")
            # Check every mention, including one hidden before a valid suffix.
            for mention in re.findall(r"@[^\s,;:()]+", body):
                if not TELEGRAM_ACCOUNT_PATTERN.fullmatch(mention):
                    errors.append(prefix + "malformed Telegram username: " + mention)
                elif mention.casefold() not in accounts:
                    errors.append(prefix + "unregistered Telegram username: " + mention)
    total = sum(counts.values())
    if not total:
        errors.append("no protocol items")
    print("Validation mode: portable (format only; semantic completeness not checked)")
    print(f"Items: {total} ({counts['done']} done, {counts['todo']} todo)")
    for error in errors:
        print("ERROR: " + error)
    for warning in warnings:
        print("WARNING: " + warning)
    print(f"Errors: {len(errors)}; Warnings: {len(warnings)}")
    return 1 if errors else 0


def find_repo_root(protocol_file: Path, explicit_root: str | None) -> Path:
    candidates: list[Path] = []
    if explicit_root:
        candidates.append(Path(explicit_root).expanduser().resolve())
    resolved_protocol = protocol_file.expanduser().resolve()
    candidates.extend([resolved_protocol.parent, *resolved_protocol.parents])
    cwd = Path.cwd().resolve()
    candidates.extend([cwd, *cwd.parents])

    for candidate in candidates:
        if (candidate / "scripts" / "sync_plan.py").exists() and (candidate / "data" / "people.json").exists():
            return candidate

    raise SystemExit(
        "Could not find fis-ai-implementation repo root. "
        "Run from the repo or pass --repo-root /path/to/fis-ai-implementation."
    )


def load_sync_plan(repo_root: Path) -> Any:
    module_path = repo_root / "scripts" / "sync_plan.py"
    spec = importlib.util.spec_from_file_location("fis_sync_plan_for_protocol_validation", module_path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"Could not load {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_telegram_accounts(repo_root: Path) -> dict[str, str]:
    registry_path = repo_root / "data" / "protocol-telegram-participants.json"
    if not registry_path.exists():
        raise SystemExit(f"Telegram participant registry not found: {registry_path}")
    import json

    payload = json.loads(registry_path.read_text(encoding="utf-8"), object_pairs_hook=unique_json_object)
    if not isinstance(payload, list):
        raise SystemExit(f"Telegram participant registry must contain a list: {registry_path}")
    accounts: dict[str, str] = {}
    for item in payload:
        account = str(item.get("account") or "").strip() if isinstance(item, dict) else ""
        if TELEGRAM_ACCOUNT_PATTERN.fullmatch(account):
            accounts[account.casefold()] = account
    return accounts


def validate_todo_assignees(raw_lines: list[str], registered_accounts: dict[str, str]) -> list[str]:
    errors: list[str] = []
    for line_number, raw_line in enumerate(raw_lines, start=1):
        match = TODO_LINE_PATTERN.match(raw_line.strip())
        if not match:
            continue
        suffix = TODO_ASSIGNEE_SUFFIX_PATTERN.search(match.group(1))
        if not suffix:
            errors.append(
                f"line {line_number}: future task must end with at least one registered Telegram username"
            )
            continue
        body = match.group(1)
        if suffix.start() == 0 or not body[suffix.start() - 1].isspace():
            errors.append(f"line {line_number}: task wording and Telegram assignees require whitespace")
        accounts = TELEGRAM_ACCOUNT_PATTERN.findall(suffix.group("suffix"))
        unknown = [account for account in accounts if account.casefold() not in registered_accounts]
        if unknown:
            errors.append(f"line {line_number}: unregistered Telegram username(s): {', '.join(unknown)}")
    return errors


def is_probably_unformatted_action(line: str) -> bool:
    stripped = line.strip()
    if not stripped or stripped.startswith(("✅", "🟡")):
        return False
    if stripped.endswith(":"):
        return False
    if re.fullmatch(r"[А-ЯA-ZЁ\s-]{4,}", stripped):
        return False
    if re.match(r"^(?:[-*•]|(?:\d{1,2}|XX|ХХ)\.\d{1,2}\.\d{4}\b)", stripped, flags=re.IGNORECASE):
        return True
    return False


def validate_project(args: argparse.Namespace) -> int:
    """Original project-parser validation; requires the external FIS repository."""
    protocol_file = Path(args.protocol).expanduser()
    if not protocol_file.exists():
        raise SystemExit(f"Protocol file not found: {protocol_file}")

    repo_root = find_repo_root(protocol_file, args.repo_root)
    registered_telegram_accounts = read_telegram_accounts(repo_root)
    sync_plan = load_sync_plan(repo_root)
    people = sync_plan.read_people_registry(repo_root / "data" / "people.json")
    parsed = sync_plan.read_protocol_milestones(protocol_file.resolve().parent, people)
    items = [item for item in parsed if item.get("protocolFile") == protocol_file.name]

    done = [item for item in items if item.get("taskStatus") == "done"]
    todo = [item for item in items if item.get("taskStatus") != "done"]
    done_without_date = [item for item in done if not item.get("dateText")]
    unmatched = [item for item in items if item.get("unmatchedAssignees")]

    print(f"Protocol: {protocol_file}")
    print(f"Parsed items: {len(items)} ({len(done)} done, {len(todo)} todo)")

    for item in sorted(items, key=lambda value: value.get("lineNumber", 0)):
        assignees = ", ".join(item.get("assignees") or []) or "-"
        date_text = item.get("dateText") or "-"
        title = item.get("title", "")
        if len(title) > 90:
            title = title[:87] + "..."
        print(
            f"{item.get('lineNumber', 0):>4} "
            f"{item.get('taskStatus', '-'):<4} "
            f"{date_text:<10} "
            f"{assignees:<36} "
            f"{title}"
        )

    raw_lines = protocol_file.read_text(encoding="utf-8").splitlines()
    todo_assignee_errors = validate_todo_assignees(raw_lines, registered_telegram_accounts)
    unformatted = [
        (line_number, line.strip())
        for line_number, line in enumerate(raw_lines, start=1)
        if is_probably_unformatted_action(line)
    ]

    print()
    error_count = len(done_without_date) + len(todo_assignee_errors) + (0 if items else 1)
    warning_count = len(unmatched) + len(unformatted)
    print(f"Errors: {error_count}; Warnings: {warning_count}")
    if not items:
        print("ERROR: no protocol items were parsed.")
        return 1

    if done_without_date:
        print(f"ERROR: {len(done_without_date)} completed items have no meeting date.")
    if todo_assignee_errors:
        print("ERROR: invalid future-task responsibility:")
        for error in todo_assignee_errors:
            print(f"  {error}")
    if unmatched:
        print("Warning: unmatched assignee aliases:")
        for item in unmatched:
            aliases = ", ".join(item.get("unmatchedAssignees") or [])
            print(f"  line {item.get('lineNumber')}: {aliases}")
    if unformatted:
        print("Warning: lines look actionable but do not start with ✅/🟡:")
        for line_number, line in unformatted[:20]:
            preview = line if len(line) <= 110 else line[:107] + "..."
            print(f"  line {line_number}: {preview}")
        if len(unformatted) > 20:
            print(f"  ... and {len(unformatted) - 20} more")

    if done_without_date or todo_assignee_errors:
        return 1
    if not unmatched and not unformatted:
        print("OK: parser recognized the protocol without warnings.")
    else:
        print("OK with warnings: review ambiguous items before reporting completion.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate FIS protocol format portably or use the original project parser.",
        epilog="Exit: 0 = checked without errors (warnings possible); 1 = validation errors; "
               "2 = usage/input/dependency error. Format validation does not prove source truth or completeness.",
    )
    parser.add_argument("protocol", help="UTF-8 Markdown protocol file")
    parser.add_argument("--mode", choices=("portable", "project"), default="portable",
                        help="portable uses standard library only (default); project uses original parser")
    parser.add_argument("--participants", help="portable: supplied JSON list of {name, account} objects")
    parser.add_argument("--date-mode", choices=("generated", "edit"), default="generated",
                        help="portable: generated enforces meeting dates for done; edit preserves accepted dates and warns on XX parts")
    parser.add_argument("--meeting-date", help="portable generated: required meeting date in DD.MM.YYYY")
    parser.add_argument("--allow-heading", action="append", default=[],
                        help="portable: extra exact local heading, repeatable; canonical names are fixed")
    parser.add_argument("--repo-root", help="project only: FIS repository root, otherwise auto-detected")
    args = parser.parse_args()
    if args.mode == "portable":
        if args.repo_root:
            parser.error("--repo-root requires --mode project")
        if not args.participants:
            parser.error("portable mode requires --participants")
        if args.date_mode == "generated" and not args.meeting_date:
            parser.error("generated mode requires --meeting-date")
        if args.meeting_date:
            error, _ = check_date(args.meeting_date, False)
            if error:
                parser.error("invalid --meeting-date: " + error)
    elif args.participants or args.meeting_date or args.allow_heading or args.date_mode != "generated":
        parser.error("portable options cannot be used in project mode")
    try:
        if args.mode == "portable":
            return validate_portable(args)
        print("Validation mode: project (original project parser)")
        return validate_project(args)
    except (OSError, ValueError) as error:
        print("ERROR: " + str(error), file=sys.stderr)
        return 2
    except SystemExit as error:
        # Historical project helpers use SystemExit(message) for missing inputs.
        if isinstance(error.code, str):
            print("ERROR: " + error.code, file=sys.stderr)
            return 2
        raise


if __name__ == "__main__":
    raise SystemExit(main())
